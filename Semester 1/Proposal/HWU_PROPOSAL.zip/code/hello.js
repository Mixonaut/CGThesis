'use strict';

console.log("Hello, World!")